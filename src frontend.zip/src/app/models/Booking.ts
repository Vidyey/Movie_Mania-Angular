import { NgIf } from '@angular/common';

export class Booking
{
 bookingId:number;
  movieId:number;
showId:number; 
bookingDate:string;
transactionId:number;
totalCost:number;
             
              
}