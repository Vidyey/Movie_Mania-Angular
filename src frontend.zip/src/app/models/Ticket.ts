export class Ticket{
 ticketId:number;
 noOfSeats:number;
seatName:Array<string>;
 ticketStatus:boolean;
screenName:string;
}