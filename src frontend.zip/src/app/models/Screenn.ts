export class Screenn
{
    screenId:number;
    theaterId:number; 
    screenName:string;  
     movieEndDate:string;
     rows:number;
     columns:number;
}
