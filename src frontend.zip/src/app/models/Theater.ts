export class Theater
{
    theaterId:number;
    theaterName:string;
    theaterCity:string;
    managerName:string;
    managerContact:string;

}