export class Customer
{
    userId:number;
     password:string; 
     securityQuestion:string;
     answer:string; 
     customerName:string; 
     dateOfBirth:string; 
    customerContact:string; 
}