export class adminContact{


userId:number; 
password:string;
securityQuestion:string;
 answer:string;
 adminName:string;
 adminContact:string;
}
export class Admin{

    username:string; 
    password:string;
    securityQuestion:string;
    answer:string;
    adminName:string;
    adminContact:string;
    

    
}